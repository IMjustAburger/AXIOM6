#!/usr/bin/env bash
# bootstrap-wrapper.sh — generates the Gradle wrapper JAR that cannot be
# included in source distributions because it is a binary file.
#
# Run this ONCE after extracting the zip, before the first ./gradlew build.
# Requirements: JDK 21+, internet access.
#
# What it does:
#   1. Checks that 'gradle' is on PATH (or falls back to downloading it)
#   2. Runs 'gradle wrapper --gradle-version 9.2.0' which downloads
#      gradle-wrapper.jar and places it in gradle/wrapper/
#   3. After this, all future builds use ./gradlew (no system Gradle needed)

set -euo pipefail

REQUIRED_GRADLE_VERSION="9.2.0"
WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"

echo "=== AXIOM Gradle wrapper bootstrap ==="

if [ -f "$WRAPPER_JAR" ]; then
  echo "Wrapper JAR already exists at $WRAPPER_JAR — nothing to do."
  exit 0
fi

# Check for a system gradle installation
if command -v gradle &>/dev/null; then
  GRADLE_CMD="gradle"
  echo "Found system Gradle: $(gradle --version | head -1)"
else
  echo ""
  echo "ERROR: 'gradle' not found on PATH."
  echo ""
  echo "To install Gradle, choose ONE of:"
  echo "  sdkman:  sdk install gradle $REQUIRED_GRADLE_VERSION"
  echo "  brew:    brew install gradle"
  echo "  manual:  https://gradle.org/releases/"
  echo ""
  echo "Alternatively, copy an existing gradle-wrapper.jar from any other"
  echo "Fabric mod project into gradle/wrapper/ and skip this script."
  echo ""
  echo "Official wrapper JAR (SHA-256 must match):"
  echo "  https://github.com/gradle/gradle/raw/v${REQUIRED_GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar"
  echo "  SHA-256: (verify at https://gradle.org/release-checksums/)"
  exit 1
fi

echo "Generating wrapper JAR with Gradle $REQUIRED_GRADLE_VERSION ..."
$GRADLE_CMD wrapper --gradle-version "$REQUIRED_GRADLE_VERSION"

if [ -f "$WRAPPER_JAR" ]; then
  echo ""
  echo "SUCCESS — $WRAPPER_JAR created."
  echo "You can now build the mod with:"
  echo "  ./gradlew build"
else
  echo "ERROR: wrapper generation failed — $WRAPPER_JAR not found."
  exit 1
fi
