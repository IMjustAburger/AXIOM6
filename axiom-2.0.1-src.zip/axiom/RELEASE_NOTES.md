# AXIOM 2.0.2 — Stability fixes

This source update contains the following fixes:

- Chunk analysis now runs on the Minecraft client thread, in a one-chunk-per-tick queue. The previous background thread accessed live world and chunk state unsafely.
- The World Scanner and Base Map now register independent anomaly listeners instead of replacing one another.
- Chunk scan state and Base Map markers are cleared when the active world/dimension changes.
- Search Engine scans loaded terrain incrementally with a per-tick work budget and does not force-load chunks.
- Stash Finder and Storage ESP inspect loaded block entities rather than repeatedly iterating large block volumes.
- Config loading no longer allows module enable callbacks to overwrite the config file partway through restoration.
- Event priorities now run from HIGHEST through LOWEST, with MONITOR last; cancelled events are delivered only to MONITOR listeners.
- Numeric ClickGUI settings can be dragged and persist after editing.
- Chunk analysis clamps the scan height to the active dimension and treats all air block states consistently.

This is a source-level stability review. A full Minecraft runtime playtest and a fresh Gradle build still need to be completed before treating the update as release-verified.
- Inventory Sorter now operates through normal inventory-menu clicks, so multiplayer changes are synchronized instead of editing only the local inventory object.

## Known limitations not changed in this pass

- The No Fall module listens for `EventPacket`, but this codebase does not currently emit outbound packet events. The toggle therefore has no effect. No movement-packet override was added as part of this stability pass.
- The World Scanner's `Scan Preset` and Base Map's `Cluster Nearby` settings are currently exposed in the GUI but are not yet connected to behavior.
