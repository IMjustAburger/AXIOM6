# AXIOM 2.0.2 — Build & Install

## Requirements
- JDK 21
- Internet access (Gradle downloads Minecraft, Fabric Loom, Fabric API)
- Minecraft Java Edition 1.21.11 with Fabric Loader >= 0.18.1

## Build
```
cd axiom
gradle wrapper --gradle-version 9.2.0     # one-time, generates the wrapper JAR
./gradlew build                           # runs JUnit tests and produces the JAR
```
The JAR is written to `build/libs/axiom-2.0.2.jar`.

1.21.11 is the last obfuscated Minecraft release. This project uses Mojang
mappings (`loom.officialMojangMappings()`); Yarn is discontinued after 1.21.11.
If a version in `gradle.properties` is not found, use the values generated at
https://fabricmc.net/develop/ for 1.21.11 (loader, Fabric API, Loom, Gradle).

## Install
1. Install Fabric Loader for 1.21.11.
2. Put `axiom-2.0.2.jar` and Fabric API into `.minecraft/mods/`.
3. Launch the game; press **INSERT** to open the ClickGUI.

Settings are saved to `.minecraft/axiom/config.json`.

## Usage scope
Use AXIOM only on single-player worlds or on servers where you have explicit
authorization. It does not bypass server permissions or anti-cheat protections.
