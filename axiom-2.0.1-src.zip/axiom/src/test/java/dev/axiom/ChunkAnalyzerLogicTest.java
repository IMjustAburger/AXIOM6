package dev.axiom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pure-Java unit tests for AXIOM chunk-analysis logic.
 *
 * These tests exercise the same algorithms used by ChunkAnalyzer / TunnelAnalyzer
 * without requiring the Minecraft runtime.  Each helper class mirrors the
 * production logic using plain int arrays so the core mathematics can be verified
 * independently of Fabric/MC classes.
 */
public class ChunkAnalyzerLogicTest {

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers that mirror production logic (no MC imports needed)
    // ─────────────────────────────────────────────────────────────────────────

    /** Block type constants matching production code roles */
    static final int AIR      = 0;
    static final int STONE    = 1;
    static final int CHEST    = 2; // crafted block
    static final int DIAMOND  = 3; // rare ore
    static final int OBSIDIAN = 4; // crafted block

    record AnomalyKind(String name, double confidence) {}

    /**
     * Pure-logic port of ChunkAnalyzer.analyze().
     * Chunk is a 16×(maxY-minY+1)×16 int array [x][y][z].
     */
    static List<AnomalyKind> analyzeChunk(int[][][] blocks,
                                          int chunkWidth,
                                          int height) {
        final double NATURAL_AIR_RATIO    = 0.08;
        final double EXCAVATION_AIR_RATIO = 0.25;
        final int    MIN_FLAT_FLOOR       = 6;

        List<AnomalyKind> results = new ArrayList<>();

        int air = 0, total = 0, crafted = 0, storage = 0, ore = 0;

        for (int x = 0; x < chunkWidth; x++) {
            for (int z = 0; z < chunkWidth; z++) {
                for (int y = 0; y < height; y++) {
                    int b = blocks[x][y][z];
                    total++;
                    if (b == AIR)                     air++;
                    if (b == CHEST)                   { crafted++; storage++; }
                    if (b == OBSIDIAN)                crafted++;
                    if (b == DIAMOND)                 ore++;
                }
            }
        }

        double airRatio = total > 0 ? (double) air / total : 0;

        // Excavation anomaly
        if (airRatio > EXCAVATION_AIR_RATIO) {
            double conf = Math.min(1.0, (airRatio - EXCAVATION_AIR_RATIO) /
                                        (1.0 - EXCAVATION_AIR_RATIO));
            results.add(new AnomalyKind("EXCAVATION", conf));
        }

        // Crafted-block detection
        if (crafted >= 3) {
            double conf = Math.min(1.0, crafted / 10.0);
            results.add(new AnomalyKind("RARE_BLOCKS", conf));
        }

        // Storage cluster
        if (storage >= 2) {
            double conf = Math.min(1.0, storage / 5.0);
            results.add(new AnomalyKind("STORAGE_CLUSTER", conf));
        }

        // High ore density
        double oreRatio = total > 0 ? (double) ore / total : 0;
        if (oreRatio > 0.005) {
            results.add(new AnomalyKind("HIGH_ORE_DENSITY", Math.min(1.0, oreRatio * 50)));
        }

        // Flat floor: count a row in Z=0 column at the min Y
        int flatRun = 0;
        for (int x = 0; x < chunkWidth; x++) {
            if (blocks[x][0][0] == AIR && (x == 0 || blocks[x-1][0][0] == AIR)) flatRun++;
            else flatRun = 0;
        }
        if (flatRun >= MIN_FLAT_FLOOR) {
            results.add(new AnomalyKind("FLAT_FLOOR", 0.5));
        }

        return results;
    }

    /** Pure-logic port of TunnelAnalyzer: finds air runs along X axis. */
    static int longestXAxisAirRun(int[][][] blocks, int chunkWidth, int height) {
        int maxRun = 0;
        // scan at mid-height, mid-Z
        int midZ = chunkWidth / 2;
        int midY = height / 2;

        int run = 0;
        for (int x = 0; x < chunkWidth; x++) {
            if (blocks[x][midY][midZ] == AIR) {
                run++;
                maxRun = Math.max(maxRun, run);
            } else {
                run = 0;
            }
        }
        return maxRun;
    }

    /** Confidence color interpolation logic (from RenderUtil.confidenceColor). */
    static int confidenceColor(double confidence) {
        // 0.0 → green (0xFF44FF44), 1.0 → red (0xFFFF4444)
        int r = (int)(0x44 + (0xFF - 0x44) * confidence);
        int g = (int)(0xFF - (0xFF - 0x44) * confidence);
        return 0xFF000000 | (r << 16) | (g << 8) | 0x44;
    }

    /** Pearl trajectory: returns number of steps until Y <= groundY. */
    static int simulatePearlSteps(double vy0, double groundY, double startY) {
        final double GRAVITY = 0.03;
        final double DRAG    = 0.99;
        double vy = vy0;
        double y  = startY;
        int steps = 0;
        while (y > groundY && steps < 10_000) {
            vy = (vy - GRAVITY) * DRAG;
            y += vy;
            steps++;
        }
        return steps;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tests
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Empty chunk (all stone) produces no anomalies")
    void emptyChunk_noAnomalies() {
        int[][][] blocks = new int[16][20][16];
        // fill everything with STONE (default int is AIR=0, so fill with 1)
        for (int x = 0; x < 16; x++)
            for (int y = 0; y < 20; y++)
                for (int z = 0; z < 16; z++)
                    blocks[x][y][z] = STONE;

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertTrue(anomalies.isEmpty(),
            "Fully-stone chunk should produce no anomalies, got: " + anomalies);
    }

    @Test
    @DisplayName("Heavily excavated chunk triggers EXCAVATION anomaly")
    void excavatedChunk_detectedAsExcavation() {
        // 16×20×16 = 5120 total; fill everything with AIR (default 0)
        int[][][] blocks = new int[16][20][16]; // all AIR
        // bury a few stone blocks to simulate a room
        blocks[0][0][0] = STONE;

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertTrue(anomalies.stream().anyMatch(a -> a.name().equals("EXCAVATION")),
            "Mostly-air chunk should trigger EXCAVATION, got: " + anomalies);
    }

    @Test
    @DisplayName("EXCAVATION confidence is in [0,1]")
    void excavationConfidence_bounded() {
        int[][][] blocks = new int[16][20][16]; // all AIR
        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        anomalies.stream()
            .filter(a -> a.name().equals("EXCAVATION"))
            .forEach(a -> {
                assertTrue(a.confidence() >= 0.0 && a.confidence() <= 1.0,
                    "Confidence must be in [0,1], was " + a.confidence());
            });
    }

    @Test
    @DisplayName("Crafted blocks trigger RARE_BLOCKS anomaly")
    void craftedBlocks_detectedAsRareBlocks() {
        int[][][] blocks = new int[16][20][16];
        // fill with stone
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        // place 5 chests (storage + crafted)
        blocks[1][1][1] = CHEST;
        blocks[2][1][1] = CHEST;
        blocks[3][1][1] = CHEST;
        blocks[4][1][1] = CHEST;
        blocks[5][1][1] = CHEST;

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertTrue(anomalies.stream().anyMatch(a -> a.name().equals("RARE_BLOCKS")),
            "5 crafted blocks should trigger RARE_BLOCKS, got: " + anomalies);
    }

    @Test
    @DisplayName("2+ storage blocks trigger STORAGE_CLUSTER anomaly")
    void storageCluster_detected() {
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        blocks[7][5][7] = CHEST;
        blocks[8][5][7] = CHEST;

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertTrue(anomalies.stream().anyMatch(a -> a.name().equals("STORAGE_CLUSTER")),
            "2 storage blocks should trigger STORAGE_CLUSTER, got: " + anomalies);
    }

    @Test
    @DisplayName("Single storage block does not trigger STORAGE_CLUSTER")
    void singleStorage_noCluster() {
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        blocks[7][5][7] = CHEST;

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertFalse(anomalies.stream().anyMatch(a -> a.name().equals("STORAGE_CLUSTER")),
            "Single storage block must NOT trigger STORAGE_CLUSTER");
    }

    @Test
    @DisplayName("High diamond density triggers HIGH_ORE_DENSITY anomaly")
    void oreDensity_triggersAnomaly() {
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        // 50 diamonds in 5120 blocks → ~1% > 0.5% threshold
        int placed = 0;
        outer:
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) {
            if (placed >= 50) break outer;
            blocks[x][y][z] = DIAMOND;
            placed++;
        }

        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertTrue(anomalies.stream().anyMatch(a -> a.name().equals("HIGH_ORE_DENSITY")),
            "1% ore density should trigger HIGH_ORE_DENSITY, got: " + anomalies);
    }

    @Test
    @DisplayName("Tunnel analyzer finds full-width air run across chunk")
    void tunnelAnalyzer_detectsFullWidthRun() {
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        // carve tunnel along X axis at mid-height, mid-Z
        int midZ = 8, midY = 10;
        for (int x=0;x<16;x++) blocks[x][midY][midZ] = AIR;

        int run = longestXAxisAirRun(blocks, 16, 20);
        assertEquals(16, run, "Full-width tunnel should produce a run of 16");
    }

    @Test
    @DisplayName("Tunnel analyzer returns 0 for solid chunk")
    void tunnelAnalyzer_solidChunk_zeroRun() {
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;

        int run = longestXAxisAirRun(blocks, 16, 20);
        assertEquals(0, run, "Solid chunk should have no air run");
    }

    @Test
    @DisplayName("Confidence color: 0.0 is fully green component")
    void confidenceColor_zeroIsGreen() {
        int color = confidenceColor(0.0);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8)  & 0xFF;
        assertTrue(g > r, "At confidence=0.0 green should dominate (g=" + g + " r=" + r + ")");
    }

    @Test
    @DisplayName("Confidence color: 1.0 is fully red component")
    void confidenceColor_oneIsRed() {
        int color = confidenceColor(1.0);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8)  & 0xFF;
        assertTrue(r > g, "At confidence=1.0 red should dominate (r=" + r + " g=" + g + ")");
    }

    @Test
    @DisplayName("Confidence color always has full alpha")
    void confidenceColor_fullAlpha() {
        for (double c : new double[]{0.0, 0.25, 0.5, 0.75, 1.0}) {
            int color = confidenceColor(c);
            int alpha = (color >> 24) & 0xFF;
            assertEquals(0xFF, alpha, "Alpha must be 0xFF at confidence=" + c);
        }
    }

    @Test
    @DisplayName("Pearl simulation: upward throw must come down")
    void pearl_upwardThrow_comesDown() {
        // Throw upward at vy=1.0 from y=64, ground at y=60
        int steps = simulatePearlSteps(1.0, 60.0, 64.0);
        assertTrue(steps > 0 && steps < 10_000,
            "Pearl should land in finite steps, got: " + steps);
    }

    @Test
    @DisplayName("Pearl simulation: downward throw reaches ground faster than upward")
    void pearl_downwardFaster() {
        int stepsDown = simulatePearlSteps(-1.0, 60.0, 64.0);
        int stepsUp   = simulatePearlSteps(1.0,  60.0, 64.0);
        assertTrue(stepsDown < stepsUp,
            "Downward throw should land faster: down=" + stepsDown + " up=" + stepsUp);
    }

    @Test
    @DisplayName("Natural air ratio (8%) does not trigger EXCAVATION")
    void naturalAir_noExcavation() {
        // Build 16×20×16 chunk with ~8% air (≈410 of 5120 blocks)
        int[][][] blocks = new int[16][20][16];
        for (int x=0;x<16;x++) for (int y=0;y<20;y++) for (int z=0;z<16;z++) blocks[x][y][z]=STONE;
        // carve a small cave (~410 blocks ≈ 8%)
        int carved = 0;
        outer:
        for (int x=1;x<15;x++) for (int y=1;y<10;y++) for (int z=1;z<15;z++) {
            if (carved >= 410) break outer;
            blocks[x][y][z] = AIR;
            carved++;
        }
        List<AnomalyKind> anomalies = analyzeChunk(blocks, 16, 20);
        assertFalse(anomalies.stream().anyMatch(a -> a.name().equals("EXCAVATION")),
            "8% air ratio should NOT trigger EXCAVATION, got: " + anomalies);
    }
}
