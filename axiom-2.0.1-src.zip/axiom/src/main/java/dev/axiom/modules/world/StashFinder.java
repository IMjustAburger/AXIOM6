package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class StashFinder extends ModuleBase {

    private final Setting.IntSetting minStorage =
        new Setting.IntSetting("Min Containers", "Minimum containers to flag a stash", 3, 1, 32);
    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Sensitivity", "Detection sensitivity",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);

    private final Map<Long, StashInfo> stashes = new ConcurrentHashMap<>();

    public StashFinder() {
        super("Stash Finder", "Locates hidden storage clusters in terrain", ModuleCategory.WORLD);
        registerSetting(minStorage);
        registerSetting(sensitivity);
    }

    @Override protected void onEnable() { stashes.clear(); }
    @Override protected void onDisable() { stashes.clear(); }

    @EventHandler
    public void onChunkLoad(EventChunkLoad event) {
        LevelChunk chunk = event.getChunk();
        ChunkPos chunkPos = chunk.getPos();
        List<BlockPos> containers = new ArrayList<>();

        // Containers have block entities. Inspect only those instead of scanning
        // every block in a 16x16x165 volume each time a chunk loads.
        for (Map.Entry<BlockPos, ?> entry : chunk.getBlockEntities().entrySet()) {
            BlockPos pos = entry.getKey();
            Block block = chunk.getBlockState(pos).getBlock();
            if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST ||
                    block == Blocks.BARREL || block instanceof ShulkerBoxBlock) {
                containers.add(pos.immutable());
            }
        }

        double confidence = Math.min(0.98, 0.35 + containers.size() * 0.08);
        double threshold = sensitivity.getValue().toConfidenceThreshold();
        if (containers.size() >= minStorage.getValue() && confidence >= threshold) {
            stashes.put(chunkPos.toLong(), new StashInfo(chunkPos, List.copyOf(containers), confidence));
        } else {
            stashes.remove(chunkPos.toLong());
        }
    }

    public Collection<StashInfo> getStashes() { return stashes.values(); }

    public record StashInfo(ChunkPos pos, List<BlockPos> containers, double confidence) {
        public BlockPos centroid() {
            if (containers.isEmpty()) return new BlockPos(pos.getMiddleBlockX(), 0, pos.getMiddleBlockZ());
            long sx = 0, sy = 0, sz = 0;
            for (BlockPos p : containers) { sx += p.getX(); sy += p.getY(); sz += p.getZ(); }
            int count = containers.size();
            return new BlockPos((int)(sx / count), (int)(sy / count), (int)(sz / count));
        }
    }
}
