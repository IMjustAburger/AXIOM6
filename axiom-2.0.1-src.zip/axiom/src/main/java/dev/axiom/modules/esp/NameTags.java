package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender2D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class NameTags extends ModuleBase {

    private final Setting.BooleanSetting showHealth = new Setting.BooleanSetting("Health",   "Show health value",    true);
    private final Setting.BooleanSetting showDist   = new Setting.BooleanSetting("Distance", "Show distance",        true);
    private final Setting.BooleanSetting showArmor  = new Setting.BooleanSetting("Armor",    "Show armor value",     false);
    private final Setting.BooleanSetting background = new Setting.BooleanSetting("Background","Draw dark background",true);

    public NameTags() {
        super("Name Tags", "Shows player name tags through walls", ModuleCategory.ESP);
        registerSetting(showHealth);
        registerSetting(showDist);
        registerSetting(showArmor);
        registerSetting(background);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender2D(EventRender2D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            Vec3 above = p.position().add(0, p.getBbHeight() + 0.3, 0);
            float[] sc = RenderUtil.worldToScreen(above);
            if (sc == null) continue;

            StringBuilder sb = new StringBuilder(p.getName().getString());
            if (showHealth.getValue())
                sb.append("  ").append(String.format("%.1f", p.getHealth())).append("hp");
            if (showDist.getValue())
                sb.append("  ").append(String.format("%.0fm", mc.player.distanceTo(p)));
            if (showArmor.getValue())
                sb.append("  ").append(p.getArmorValue()).append("❤");

            String txt = sb.toString();
            int tw = mc.font.width(txt);
            if (background.getValue())
                RenderUtil.drawRect(e.getGraphics(), (int)sc[0]-tw/2-2, (int)sc[1]-2, tw+4, 10, 0x88000000);
            RenderUtil.drawText(e.getGraphics(), txt, (int)sc[0]-tw/2, (int)sc[1], 0xFFFFFFFF, true);
        }
    }
}
