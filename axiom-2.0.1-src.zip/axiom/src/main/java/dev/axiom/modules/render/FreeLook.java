package dev.axiom.modules.render;

import dev.axiom.core.config.Setting;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import org.lwjgl.glfw.GLFW;

/**
 * FreeLook — hold a key to look around without rotating the character.
 *
 * Camera injection is done by MixinCamera.java (applies yaw/pitch offset).
 * Mouse delta capture is done by MixinMouseHandler.java (calls accumulate()).
 * Key hold state is set by MixinMouseHandler when the hold key is pressed.
 */
public class FreeLook extends ModuleBase {

    private final Setting.IntSetting holdKey =
        new Setting.IntSetting("Hold Key",
            "GLFW key code to hold for free-look (default: Left Alt)",
            GLFW.GLFW_KEY_LEFT_ALT, 0, 400);

    private float   yawOffset   = 0f;
    private float   pitchOffset = 0f;
    private boolean held        = false;

    public FreeLook() {
        super("Free Look", "Hold a key to look around without turning your character", ModuleCategory.RENDER);
        registerSetting(holdKey);
    }

    @Override
    protected void onEnable() {
        yawOffset   = 0f;
        pitchOffset = 0f;
        held        = false;
    }

    @Override
    protected void onDisable() {
        yawOffset   = 0f;
        pitchOffset = 0f;
        held        = false;
    }

    /** Called each frame by MixinMouseHandler with the raw mouse delta (in pixels × sensitivity). */
    public void accumulate(double dx, double dy) {
        if (!held) return;
        yawOffset   += (float) dx;
        pitchOffset += (float) dy;
        pitchOffset  = Math.max(-90f, Math.min(90f, pitchOffset));
    }

    public void setHeld(boolean h) { this.held = h; }
    public boolean isHeld()         { return held; }
    public int     getHoldKey()     { return holdKey.getValue(); }
    public float   getYawOffset()   { return yawOffset; }
    public float   getPitchOffset() { return pitchOffset; }
}
