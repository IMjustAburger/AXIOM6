package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.event.events.EventChunkUnload;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.world.ChunkAnomaly;
import dev.axiom.core.world.ScanQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Consumer;

public class WorldScanner extends ModuleBase {

    private final Setting.EnumSetting<Setting.Sensitivity> sensitivity =
        new Setting.EnumSetting<>("Sensitivity", "Detection sensitivity level",
            Setting.Sensitivity.MEDIUM, Setting.Sensitivity.class);

    private final Setting.EnumSetting<Setting.Preset> preset =
        new Setting.EnumSetting<>("Scan Preset", "Performance vs quality preset",
            Setting.Preset.BALANCED, Setting.Preset.class);

    private final Setting.IntSetting scanMinY =
        new Setting.IntSetting("Scan Min Y", "Lowest Y level to scan", -60, -64, 320);

    private final Setting.IntSetting scanMaxY =
        new Setting.IntSetting("Scan Max Y", "Highest Y level to scan", 64, -64, 320);

    private final Setting.BooleanSetting autoScan =
        new Setting.BooleanSetting("Auto Scan", "Automatically scan newly loaded chunks", true);

    private int foundCount = 0;
    private Level lastLevel;
    private final Consumer<List<ChunkAnomaly>> anomalyListener = this::onAnomalies;

    public WorldScanner() {
        super("World Scanner", "Scans terrain for base remnants and anomalies", ModuleCategory.WORLD);
        registerSetting(sensitivity);
        registerSetting(preset);
        registerSetting(scanMinY);
        registerSetting(scanMaxY);
        registerSetting(autoScan);
    }

    @Override protected void onEnable() {
        ScanQueue q = ScanQueue.getInstance();
        if (Minecraft.getInstance().level != lastLevel) {
            lastLevel = Minecraft.getInstance().level;
            foundCount = 0;
        }
        q.setMinY(scanMinY.getValue());
        q.setMaxY(scanMaxY.getValue());
        q.setConfidenceThreshold(sensitivity.getValue().toConfidenceThreshold());
        q.addListener(anomalyListener);
        q.start();
        foundCount = 0;
    }

    @Override protected void onDisable() {
        ScanQueue q = ScanQueue.getInstance();
        q.removeListener(anomalyListener);
        q.stop();
    }

    @EventHandler
    public void onChunkLoad(EventChunkLoad e) {
        if (!autoScan.getValue()) return;
        ScanQueue.getInstance().enqueue(e.getChunk());
    }

    @EventHandler
    public void onChunkUnload(EventChunkUnload e) {
        ScanQueue.getInstance().invalidate(e.getPos());
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        ScanQueue q = ScanQueue.getInstance();
        if (Minecraft.getInstance().level != lastLevel) {
            lastLevel = Minecraft.getInstance().level;
            foundCount = 0;
        }
        q.setMinY(scanMinY.getValue());
        q.setMaxY(scanMaxY.getValue());
        q.setConfidenceThreshold(sensitivity.getValue().toConfidenceThreshold());
        q.tick();
    }

    private void onAnomalies(List<ChunkAnomaly> anomalies) {
        foundCount += anomalies.size();
    }

    public int getFoundCount() { return foundCount; }
    public void clearFound()   { foundCount = 0; ScanQueue.getInstance().clear(); }
}
