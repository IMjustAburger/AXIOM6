package dev.axiom.modules.combat;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;

public class KillAura extends ModuleBase {

    private final Setting.DoubleSetting  range       = new Setting.DoubleSetting("Range",    "Attack range",          4.2, 2.0, 8.0);
    private final Setting.IntSetting     cps         = new Setting.IntSetting("CPS",         "Clicks per second",     10,  1,  20);
    private final Setting.BooleanSetting players     = new Setting.BooleanSetting("Players", "Target players",        true);
    private final Setting.BooleanSetting mobs        = new Setting.BooleanSetting("Mobs",    "Target hostile mobs",   true);
    private final Setting.BooleanSetting passiveMobs = new Setting.BooleanSetting("Passive", "Target passive mobs",   false);
    private final Setting.BooleanSetting rotate      = new Setting.BooleanSetting("Rotate",  "Face target",           true);

    private long lastAttack = 0;

    public KillAura() {
        super("Kill Aura", "Automatically attacks nearby entities", ModuleCategory.COMBAT);
        registerSetting(range);
        registerSetting(cps);
        registerSetting(players);
        registerSetting(mobs);
        registerSetting(passiveMobs);
        registerSetting(rotate);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        long now = System.currentTimeMillis();
        if (now - lastAttack < 1000L / cps.getValue()) return;

        double r = range.getValue();
        AABB box = mc.player.getBoundingBox().inflate(r);
        List<LivingEntity> targets = mc.level.getEntitiesOfClass(LivingEntity.class, box,
            en -> en != mc.player && en.isAlive() && canTarget(en));
        if (targets.isEmpty()) return;

        LivingEntity target = targets.stream()
            .min(Comparator.comparingDouble((LivingEntity en) -> en.distanceTo(mc.player))).orElse(null);
        if (target == null || mc.player.distanceTo(target) > r) return;

        if (rotate.getValue()) {
            var delta = target.position().subtract(mc.player.position());
            float yaw   = (float)(Math.toDegrees(Math.atan2(-delta.x, delta.z)));
            float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y,
                Math.sqrt(delta.x * delta.x + delta.z * delta.z))));
            mc.player.setYRot(yaw);
            mc.player.setXRot(pitch);
        }

        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
        lastAttack = now;
    }

    private boolean canTarget(LivingEntity en) {
        if (en instanceof Player && !players.getValue()) return false;
        if (en instanceof Monster && !mobs.getValue()) return false;
        if (!(en instanceof Player) && !(en instanceof Monster) && !passiveMobs.getValue()) return false;
        return true;
    }
}
