package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.List;

/** Incremental search of already-loaded terrain; work is budgeted per client tick. */
public class SearchEngine extends ModuleBase {

    private static final int BLOCKS_PER_TICK = 4096;

    private final Setting.IntSetting searchRadius = new Setting.IntSetting("Search Radius", "Radius to search around player", 64, 16, 256);
    private final Setting.BooleanSetting searchChests = new Setting.BooleanSetting("Chests", "Search for chests and barrels", true);
    private final Setting.BooleanSetting searchOres = new Setting.BooleanSetting("Rare Ores", "Search for diamond/emerald/ancient debris", true);
    private final Setting.BooleanSetting searchCrafted = new Setting.BooleanSetting("Crafted Blocks", "Search for crafted/unnatural blocks", false);

    private final List<BlockPos> found = new ArrayList<>();
    private Level scanLevel;
    private int originX;
    private int originZ;
    private int radius;
    private int minY;
    private int yCount;
    private int xCount;
    private int xIndex;
    private int yIndex;
    private int zIndex;
    private int refreshDelay;
    private boolean scanning;

    public SearchEngine() {
        super("Search Engine", "Locates specific blocks in loaded chunks", ModuleCategory.WORLD);
        registerSetting(searchRadius);
        registerSetting(searchChests);
        registerSetting(searchOres);
        registerSetting(searchCrafted);
    }

    @Override protected void onEnable() {
        found.clear();
        scanLevel = null;
        scanning = false;
        refreshDelay = 0;
    }

    @Override protected void onDisable() {
        found.clear();
        scanning = false;
        scanLevel = null;
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            found.clear();
            scanLevel = null;
            scanning = false;
            return;
        }

        Level level = mc.level;
        BlockPos playerPos = mc.player.blockPosition();
        int wantedRadius = searchRadius.getValue();
        boolean contextChanged = level != scanLevel
            || Math.floorDiv(playerPos.getX(), 16) != Math.floorDiv(originX, 16)
            || Math.floorDiv(playerPos.getZ(), 16) != Math.floorDiv(originZ, 16)
            || wantedRadius != radius;

        if (contextChanged) {
            beginScan(level, playerPos, wantedRadius);
        } else if (!scanning && refreshDelay > 0) {
            refreshDelay--;
        } else if (!scanning) {
            beginScan(level, playerPos, wantedRadius);
        }

        processBudget(level);
    }

    private void beginScan(Level level, BlockPos center, int wantedRadius) {
        scanLevel = level;
        originX = center.getX();
        originZ = center.getZ();
        radius = wantedRadius;
        minY = level.getMinY();
        int maxY = level.getMaxY() - 1;
        yCount = Math.max(0, (maxY - minY) / 2 + 1);
        xCount = radius + 1;
        xIndex = yIndex = zIndex = 0;
        found.clear();
        scanning = yCount > 0;
        refreshDelay = 0;
    }

    private void processBudget(Level level) {
        int processed = 0;
        while (scanning && processed < BLOCKS_PER_TICK) {
            int x = originX - radius + xIndex * 2;
            int y = minY + yIndex * 2;
            int z = originZ - radius + zIndex * 2;
            BlockPos pos = new BlockPos(x, y, z);

            // Never query an unloaded chunk: the search must not cause chunk loads.
            if (level.hasChunkAt(pos) && matches(level.getBlockState(pos).getBlock())) {
                found.add(pos.immutable());
            }
            processed++;
            advanceCursor();
        }
    }

    private void advanceCursor() {
        yIndex++;
        if (yIndex >= yCount) {
            yIndex = 0;
            zIndex++;
            if (zIndex >= xCount) {
                zIndex = 0;
                xIndex++;
                if (xIndex >= xCount) {
                    scanning = false;
                    refreshDelay = 200; // Refresh no more than once every ten seconds.
                }
            }
        }
    }

    private boolean matches(Block block) {
        if (searchChests.getValue() &&
            (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST || block == Blocks.BARREL)) return true;
        if (searchOres.getValue() &&
            (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE ||
             block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE ||
             block == Blocks.ANCIENT_DEBRIS)) return true;
        return searchCrafted.getValue() &&
            (block == Blocks.CRAFTING_TABLE || block == Blocks.FURNACE || block == Blocks.ENCHANTING_TABLE ||
             block == Blocks.ANVIL || block == Blocks.OBSIDIAN);
    }

    public List<BlockPos> getFound() { return List.copyOf(found); }
}
