package dev.axiom.modules.movement;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public class AutoLog extends ModuleBase {

    private final Setting.IntSetting threshold =
        new Setting.IntSetting("HP Threshold", "Disconnect when health falls to this level", 6, 1, 20);

    public AutoLog() {
        super("Auto Log", "Disconnects from server when HP drops low", ModuleCategory.MOVEMENT);
        registerSetting(threshold);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;
        if (mc.player.getHealth() <= threshold.getValue()) {
            // Connection.disconnect(Component) closes the connection with a message
            mc.getConnection().getConnection().disconnect(
                Component.literal("§c[AXIOM] AutoLog triggered — health critically low"));
        }
    }
}
