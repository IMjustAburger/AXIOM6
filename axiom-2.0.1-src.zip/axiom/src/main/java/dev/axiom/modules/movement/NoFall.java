package dev.axiom.modules.movement;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventPacket;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public class NoFall extends ModuleBase {

    private final Setting.BooleanSetting packetMode =
        new Setting.BooleanSetting("Packet Mode", "Send onGround=true in movement packets while falling", true);
    private final Setting.IntSetting fallThreshold =
        new Setting.IntSetting("Min Fall Distance", "Min fall blocks before activating", 3, 1, 10);

    public NoFall() {
        super("No Fall", "Prevents fall damage", ModuleCategory.MOVEMENT);
        registerSetting(packetMode);
        registerSetting(fallThreshold);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onPacket(EventPacket e) {
        if (!packetMode.getValue()) return;
        if (e.getDirection() != EventPacket.Direction.OUTBOUND) return;
        if (!(e.getPacket() instanceof ServerboundMovePlayerPacket pkt)) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.player.fallDistance < fallThreshold.getValue()) return;

        // Cancel the original and resend with onGround=true using current player coords.
        // ServerboundMovePlayerPacket.PosRot(x, y, z, yRot, xRot, onGround, horizontalCollision)  [1.21.2+]
        // We read position directly from the player to avoid any accessor variance.
        e.setCancelled(true);
        mc.player.connection.send(
            new ServerboundMovePlayerPacket.PosRot(
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                mc.player.getYRot(),
                mc.player.getXRot(),
                true,
                mc.player.horizontalCollision));
    }
}
