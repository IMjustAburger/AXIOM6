package dev.axiom.modules.render;

import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;

public class Fullbright extends ModuleBase {

    private double savedGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Removes darkness — renders everything at max brightness", ModuleCategory.RENDER);
    }

    @Override
    protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            savedGamma = mc.options.gamma().get();
            mc.options.gamma().set(10.0);
        }
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            mc.options.gamma().set(savedGamma);
        }
    }
}
