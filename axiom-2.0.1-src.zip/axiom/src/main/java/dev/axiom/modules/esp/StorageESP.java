package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class StorageESP extends ModuleBase {

    private final Setting.ColorSetting chestColor = new Setting.ColorSetting("Chest Color", "Chest/trapped chest", 0xCCFFD700);
    private final Setting.ColorSetting barrelColor = new Setting.ColorSetting("Barrel Color", "Barrel containers", 0xCCCD853F);
    private final Setting.ColorSetting shulkerColor = new Setting.ColorSetting("Shulker Color", "Shulker boxes", 0xCCFF69B4);
    private final Setting.IntSetting radius = new Setting.IntSetting("Radius", "Scan radius around player", 64, 16, 256);
    private final Setting.BooleanSetting filled = new Setting.BooleanSetting("Filled", "Draw filled boxes", true);

    private final List<BlockPos> chests = new ArrayList<>();
    private final List<BlockPos> barrels = new ArrayList<>();
    private final List<BlockPos> shulkers = new ArrayList<>();
    private int tick;
    private Level scannedLevel;
    private int lastCenterChunkX = Integer.MIN_VALUE;
    private int lastCenterChunkZ = Integer.MIN_VALUE;
    private int lastRadius = -1;

    public StorageESP() {
        super("Storage ESP", "Highlights all storage containers", ModuleCategory.ESP);
        registerSetting(chestColor);
        registerSetting(barrelColor);
        registerSetting(shulkerColor);
        registerSetting(radius);
        registerSetting(filled);
    }

    @Override protected void onEnable() {
        clearResults();
        tick = 0;
        scannedLevel = null;
    }
    @Override protected void onDisable() {
        clearResults();
        scannedLevel = null;
    }

    @EventHandler
    public void onTick(EventTick event) {
        if (event.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            clearResults();
            scannedLevel = null;
            return;
        }
        int chunkX = Math.floorDiv(mc.player.blockPosition().getX(), 16);
        int chunkZ = Math.floorDiv(mc.player.blockPosition().getZ(), 16);
        boolean contextChanged = mc.level != scannedLevel || chunkX != lastCenterChunkX
            || chunkZ != lastCenterChunkZ || radius.getValue() != lastRadius;
        if (contextChanged || ++tick >= 20) {
            tick = 0;
            scan(mc);
            scannedLevel = mc.level;
            lastCenterChunkX = chunkX;
            lastCenterChunkZ = chunkZ;
            lastRadius = radius.getValue();
        }
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.level != scannedLevel) return;
        Vec3 camera = mc.gameRenderer.getMainCamera().position();
        renderList(event, chests, chestColor.getEffectiveColor(), camera);
        renderList(event, barrels, barrelColor.getEffectiveColor(), camera);
        renderList(event, shulkers, shulkerColor.getEffectiveColor(), camera);
    }

    private void renderList(EventRender3D event, List<BlockPos> list, int color, Vec3 camera) {
        for (BlockPos pos : list) {
            double x = pos.getX() - camera.x;
            double y = pos.getY() - camera.y;
            double z = pos.getZ() - camera.z;
            if (filled.getValue())
                RenderUtil.drawFilledBox(event.getPoseStack(), x, y, z, x + 1, y + 1, z + 1, color & 0x44FFFFFF);
            RenderUtil.drawBox(event.getPoseStack(), x, y, z, x + 1, y + 1, z + 1, color);
        }
    }

    private void scan(Minecraft mc) {
        clearResults();
        int centerX = mc.player.blockPosition().getX();
        int centerZ = mc.player.blockPosition().getZ();
        int scanRadius = radius.getValue();
        int centerChunkX = Math.floorDiv(centerX, 16);
        int centerChunkZ = Math.floorDiv(centerZ, 16);
        int chunkRadius = (scanRadius + 15) / 16;

        for (int chunkX = centerChunkX - chunkRadius; chunkX <= centerChunkX + chunkRadius; chunkX++) {
            for (int chunkZ = centerChunkZ - chunkRadius; chunkZ <= centerChunkZ + chunkRadius; chunkZ++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunkNow(chunkX, chunkZ);
                if (chunk == null) continue; // Never force-load terrain for an ESP scan.

                for (Map.Entry<BlockPos, ?> entry : chunk.getBlockEntities().entrySet()) {
                    BlockPos pos = entry.getKey();
                    if (Math.abs(pos.getX() - centerX) > scanRadius ||
                            Math.abs(pos.getZ() - centerZ) > scanRadius) continue;
                    Block block = chunk.getBlockState(pos).getBlock();
                    if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST) chests.add(pos.immutable());
                    else if (block == Blocks.BARREL) barrels.add(pos.immutable());
                    else if (block instanceof ShulkerBoxBlock) shulkers.add(pos.immutable());
                }
            }
        }
    }

    private void clearResults() {
        chests.clear();
        barrels.clear();
        shulkers.clear();
    }
}
