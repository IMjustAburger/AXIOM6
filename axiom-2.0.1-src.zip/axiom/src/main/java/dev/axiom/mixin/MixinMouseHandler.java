package dev.axiom.mixin;

import dev.axiom.core.module.ModuleManager;
import dev.axiom.modules.render.FreeLook;
import net.minecraft.client.MouseHandler;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class MixinMouseHandler {

    /** Last cursor position seen by this hook (tracked here, so no private-field shadowing). */
    private double axiom$lastX = Double.NaN;
    private double axiom$lastY = Double.NaN;

    @Inject(method = "onMove", at = @At("HEAD"))
    private void axiom$onMouseMove(long windowPtr, double newX, double newY, CallbackInfo ci) {
        double dx = Double.isNaN(axiom$lastX) ? 0 : newX - axiom$lastX;
        double dy = Double.isNaN(axiom$lastY) ? 0 : newY - axiom$lastY;
        axiom$lastX = newX;
        axiom$lastY = newY;

        FreeLook fl = ModuleManager.getInstance().getModule(FreeLook.class);
        if (fl == null || !fl.isEnabled()) return;

        boolean held = GLFW.glfwGetKey(windowPtr, fl.getHoldKey()) == GLFW.GLFW_PRESS;
        fl.setHeld(held);
        if (!held) return;

        fl.accumulate(dx * 0.15, dy * 0.15);
    }
}
