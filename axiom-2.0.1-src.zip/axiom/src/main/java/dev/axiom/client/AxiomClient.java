package dev.axiom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.axiom.core.config.ConfigManager;
import dev.axiom.core.event.EventBus;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.event.events.EventChunkUnload;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.core.util.EspRenderer;
import dev.axiom.gui.click.ClickGUI;
import dev.axiom.gui.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AxiomClient implements ClientModInitializer {

    public static final String MOD_ID   = "axiom";
    public static final String MOD_NAME = "AXIOM";
    public static final Logger LOGGER   = LoggerFactory.getLogger(MOD_NAME);

    private static AxiomClient INSTANCE;
    private static EventBus    eventBus;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        LOGGER.info("AXIOM World Intelligence System initializing...");

        eventBus = EventBus.getInstance();
        EspRenderer.init();
        ModuleManager.getInstance().loadAll();
        ConfigManager.getInstance().load();

        // Always-on renderers and input handlers
        new HudRenderer();
        eventBus.subscribe(this);   // for ClickGUI open key

        // 3D pass: fire EventRender3D, then draw everything the modules queued.
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(context -> {
            PoseStack ps = context.matrices() != null ? context.matrices() : new PoseStack();
            float partial = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
            eventBus.post(new EventRender3D(ps, partial));
            EspRenderer.flush();
        });

        // Chunk lifecycle (client-side data the game has already received)
        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) ->
            eventBus.post(new EventChunkLoad(chunk)));
        ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) ->
            eventBus.post(new EventChunkUnload(chunk.getPos())));

        LOGGER.info("AXIOM initialized — {} modules loaded.",
                ModuleManager.getInstance().getAll().size());
    }

    /** Open ClickGUI on INSERT key press. */
    @EventHandler
    public void onKey(EventKey e) {
        if (e.getKey() == GLFW.GLFW_KEY_INSERT && e.getAction() == GLFW.GLFW_PRESS) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null) {
                mc.setScreen(new ClickGUI());
            }
        }
    }

    public static AxiomClient getInstance()  { return INSTANCE; }
    public static EventBus   getEventBus()   { return EventBus.getInstance(); }
}
