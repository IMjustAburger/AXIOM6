package dev.axiom.core.module;

public enum ModuleCategory {
    WORLD    ("World Analysis"),
    ESP      ("Visual / ESP"),
    COMBAT   ("Combat"),
    MOVEMENT ("Movement"),
    RENDER   ("Render"),
    UTILITY  ("Utility");

    public final String displayName;
    ModuleCategory(String d){ displayName=d; }
}
