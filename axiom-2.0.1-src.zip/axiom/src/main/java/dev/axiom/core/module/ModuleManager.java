package dev.axiom.core.module;

import dev.axiom.modules.combat.*;
import dev.axiom.modules.esp.*;
import dev.axiom.modules.movement.*;
import dev.axiom.modules.render.*;
import dev.axiom.modules.utility.*;
import dev.axiom.modules.world.*;

import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {

    private static final ModuleManager INSTANCE = new ModuleManager();
    public static ModuleManager getInstance() { return INSTANCE; }

    private final List<ModuleBase> modules = new ArrayList<>();

    private ModuleManager() {}

    public void registerModule(ModuleBase m) {
        for (ModuleBase existing : modules)
            if (existing.getClass() == m.getClass())
                throw new IllegalStateException("Duplicate module: " + m.getName());
        modules.add(m);
    }

    public void loadAll() {
        // ── WORLD ANALYSIS ──────────────────────────────────────────────────
        registerModule(new WorldScanner());
        registerModule(new NewChunks());
        registerModule(new SearchEngine());
        registerModule(new StashFinder());
        registerModule(new TunnelAnalyzer());
        registerModule(new BaseMap());

        // ── ESP / VISUAL ────────────────────────────────────────────────────
        registerModule(new PlayerESP());
        registerModule(new MobESP());
        registerModule(new BlockESP());
        registerModule(new StorageESP());
        registerModule(new OreESP());
        registerModule(new HoleESP());
        registerModule(new ChunkESP());
        registerModule(new TerrainAnomalyESP());
        registerModule(new TunnelESP());
        registerModule(new NameTags());
        registerModule(new PearlTrajectory());
        registerModule(new TargetHUD());

        // ── COMBAT ──────────────────────────────────────────────────────────
        registerModule(new KillAura());
        registerModule(new CrystalAura());
        registerModule(new AutoTotem());
        registerModule(new Surround());

        // ── MOVEMENT ────────────────────────────────────────────────────────
        registerModule(new Sprint());
        registerModule(new NoFall());
        registerModule(new AutoLog());

        // ── RENDER ──────────────────────────────────────────────────────────
        registerModule(new Fullbright());
        registerModule(new FreeLook());

        // ── UTILITY ─────────────────────────────────────────────────────────
        registerModule(new InventorySorter());
        registerModule(new MiddleClickFriend());
    }

    @SuppressWarnings("unchecked")
    public <T extends ModuleBase> T getModule(Class<T> c) {
        for (ModuleBase m : modules) if (c.isInstance(m)) return (T) m;
        return null;
    }

    public List<ModuleBase> getByCategory(ModuleCategory cat) {
        return modules.stream().filter(m -> m.getCategory()==cat).collect(Collectors.toList());
    }

    public List<ModuleBase> getAll() { return Collections.unmodifiableList(modules); }

    public void onKey(int keyCode) {
        if (keyCode <= 0) return;
        for (ModuleBase m : modules) if (m.getKeyBind() == keyCode) m.toggle();
    }
}
