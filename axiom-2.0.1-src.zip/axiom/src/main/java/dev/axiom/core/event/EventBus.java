package dev.axiom.core.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {

    private static final EventBus INSTANCE = new EventBus();
    public static EventBus getInstance() { return INSTANCE; }

    private record ListenerEntry(Object owner, Method method, int priorityOrd) {}

    private final Map<Class<?>, CopyOnWriteArrayList<ListenerEntry>> listeners = new ConcurrentHashMap<>();

    private EventBus() {}

    public void subscribe(Object listener) {
        for (Method m : listener.getClass().getMethods()) {
            EventHandler ann = m.getAnnotation(EventHandler.class);
            if (ann == null || m.getParameterCount() != 1) continue;
            Class<?> eventType = m.getParameterTypes()[0];
            m.setAccessible(true);
            int order = ann.priority() == Priority.MONITOR ? -1 : ann.priority().ordinal();
            CopyOnWriteArrayList<ListenerEntry> entries = listeners.computeIfAbsent(
                eventType, k -> new CopyOnWriteArrayList<>());
            entries.add(new ListenerEntry(listener, m, order));
            entries.sort(Comparator.comparingInt(ListenerEntry::priorityOrd).reversed());
        }
    }

    public void unsubscribe(Object listener) {
        listeners.values().forEach(list -> list.removeIf(e -> e.owner() == listener));
    }

    public <E extends Event> E post(E event) {
        CopyOnWriteArrayList<ListenerEntry> list = listeners.get(event.getClass());
        if (list == null) return event;
        for (ListenerEntry entry : list) {
            // Skip non-MONITOR listeners when the event has been cancelled
            if (event instanceof ICancellable ic && ic.isCancelled()
                    && entry.priorityOrd() != -1) continue;
            try { entry.method().invoke(entry.owner(), event); }
            catch (Exception ex) {
                Throwable cause = ex.getCause();
                (cause != null ? cause : ex).printStackTrace();
            }
        }
        return event;
    }
}
