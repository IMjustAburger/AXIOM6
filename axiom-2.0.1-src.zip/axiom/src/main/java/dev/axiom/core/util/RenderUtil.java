package dev.axiom.core.util;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

public class RenderUtil {
    private static final Minecraft mc = Minecraft.getInstance();

    // ── 2D ────────────────────────────────────────────────────────────────────
    public static void drawText(GuiGraphics gg, String text, int x, int y, int color, boolean shadow) {
        if (shadow) gg.drawString(mc.font, text, x, y, color);
        else        gg.drawString(mc.font, text, x, y, color, false);
    }

    public static void drawRect(GuiGraphics gg, int x, int y, int w, int h, int color) {
        gg.fill(x, y, x+w, y+h, color);
    }

    public static void drawBorder(GuiGraphics gg, int x, int y, int w, int h, int color) {
        gg.fill(x,   y,   x+w, y+1,   color);
        gg.fill(x,   y+h-1, x+w, y+h, color);
        gg.fill(x,   y,   x+1, y+h,   color);
        gg.fill(x+w-1, y, x+w, y+h,   color);
    }

    // ── 3D (batched through EspRenderer; coordinates are camera-relative) ─────
    public static void drawBox(PoseStack ps, double x1, double y1, double z1,
                               double x2, double y2, double z2, int argb) {
        EspRenderer.outlineBox(ps.last().pose(), (float)x1,(float)y1,(float)z1,
                                                 (float)x2,(float)y2,(float)z2, argb);
    }

    public static void drawFilledBox(PoseStack ps, double x1, double y1, double z1,
                                     double x2, double y2, double z2, int argb) {
        EspRenderer.filledBox(ps.last().pose(), (float)x1,(float)y1,(float)z1,
                                                (float)x2,(float)y2,(float)z2, argb);
    }

    public static void drawLine(PoseStack ps, double x1, double y1, double z1,
                                double x2, double y2, double z2, int argb) {
        EspRenderer.line(ps.last().pose(), (float)x1,(float)y1,(float)z1,
                                           (float)x2,(float)y2,(float)z2, argb);
    }

    // ── World → Screen projection ─────────────────────────────────────────────
    /** Returns {x, y} in GUI-scaled coordinates, or null when the point is behind the camera. */
    public static float[] worldToScreen(Vec3 world) {
        net.minecraft.client.Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 rel = world.subtract(cam.position());
        // Rotate the camera-relative vector into view space (camera looks down -Z).
        org.joml.Quaternionfc q = cam.rotation();
        org.joml.Vector3f v = new org.joml.Vector3f((float) rel.x, (float) rel.y, (float) rel.z);
        q.conjugate(new org.joml.Quaternionf()).transform(v);
        float depth = -v.z;
        if (depth <= 0.05f) return null;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double fov = Math.toRadians(mc.options.fov().get());      // vertical FOV
        double f   = (sh / 2.0) / Math.tan(fov / 2.0);
        float sx = (float) (sw / 2.0 + v.x * f / depth);
        float sy = (float) (sh / 2.0 - v.y * f / depth);
        return new float[]{sx, sy};
    }

    public static int withAlpha(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | (alpha << 24);
    }

    public static int lerpColor(int c1, int c2, float t) {
        int a1=(c1>>24&0xFF), r1=(c1>>16&0xFF), g1=(c1>>8&0xFF), b1=(c1&0xFF);
        int a2=(c2>>24&0xFF), r2=(c2>>16&0xFF), g2=(c2>>8&0xFF), b2=(c2&0xFF);
        int a=(int)(a1+t*(a2-a1)), r=(int)(r1+t*(r2-r1)),
            g=(int)(g1+t*(g2-g1)), b=(int)(b1+t*(b2-b1));
        return (a<<24)|(r<<16)|(g<<8)|b;
    }

    public static int confidenceColor(double confidence) {
        if (confidence >= 0.80) return 0xCCFF3333; // red
        if (confidence >= 0.60) return 0xCCFF8C00; // orange
        if (confidence >= 0.40) return 0xCCFFD700; // yellow
        return 0xCC44FF44;                          // green
    }
}
