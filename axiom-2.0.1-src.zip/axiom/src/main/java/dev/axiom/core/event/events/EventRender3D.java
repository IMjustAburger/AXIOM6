package dev.axiom.core.event.events;
import dev.axiom.core.event.Event;
import com.mojang.blaze3d.vertex.PoseStack;
public class EventRender3D extends Event {
    private final PoseStack poseStack;
    private final float partialTick;
    public EventRender3D(PoseStack ps, float pt) { poseStack = ps; partialTick = pt; }
    public PoseStack getPoseStack()  { return poseStack; }
    public float     getPartialTick(){ return partialTick; }
}
