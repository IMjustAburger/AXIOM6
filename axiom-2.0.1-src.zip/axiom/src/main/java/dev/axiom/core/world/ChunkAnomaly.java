package dev.axiom.core.world;

import net.minecraft.world.level.ChunkPos;

public class ChunkAnomaly {
    public enum Type {
        EXCAVATION("Excavation", "Large artificial void detected"),
        TUNNEL("Tunnel", "Artificial tunnel network detected"),
        FLAT_FLOOR("Flat Floor", "Unnaturally flat surface at this depth"),
        STORAGE_CLUSTER("Storage Cluster", "Cluster of storage containers"),
        RARE_BLOCKS("Rare Blocks", "Unusual concentration of rare/crafted blocks"),
        HIGH_ORE_DENSITY("Ore Cluster", "Higher-than-natural ore density"),
        COMPOSITE("Composite", "Multiple anomaly types detected");

        public final String label, description;
        Type(String l, String d) { label=l; description=d; }
    }

    public final ChunkPos   pos;
    public final Type       type;
    public final double     confidence;   // 0.0 – 1.0
    public final String     detail;
    public final long       detectedAt;

    public ChunkAnomaly(ChunkPos pos, Type type, double confidence, String detail) {
        this.pos        = pos;
        this.type       = type;
        this.confidence = confidence;
        this.detail     = detail;
        this.detectedAt = System.currentTimeMillis();
    }

    public boolean isHighConfidence() { return confidence >= 0.65; }

    @Override public String toString() {
        return String.format("[%s] %s @%d,%d (%.0f%%)",
            type.label, detail, pos.x, pos.z, confidence*100);
    }
}
