package dev.axiom.core.world;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Scans already-loaded chunks on the Minecraft client thread. Minecraft world
 * objects are not thread-safe, so no worker thread may read chunk/block data.
 */
public final class ScanQueue {

    private static final ScanQueue INSTANCE = new ScanQueue();
    public static ScanQueue getInstance() { return INSTANCE; }

    private static final int MAX_PENDING = 2048;

    private final ArrayDeque<ChunkPos> pending = new ArrayDeque<>(MAX_PENDING);
    private final Set<Long> queued = ConcurrentHashMap.newKeySet();
    private final Set<Long> scanned = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<Long, List<ChunkAnomaly>> results = new ConcurrentHashMap<>();
    private final CopyOnWriteArrayList<Consumer<List<ChunkAnomaly>>> listeners = new CopyOnWriteArrayList<>();

    private boolean running;
    private Level activeLevel;
    private int minY = -60;
    private int maxY = 60;
    private double confidenceThreshold = 0.55;

    private ScanQueue() {}

    /** Starts queue processing. Call from the client thread. */
    public void start() {
        running = true;
    }

    /** Stops processing without leaving a worker thread behind. */
    public void stop() {
        running = false;
    }

    public void enqueue(LevelChunk chunk) {
        if (chunk == null) return;
        Level chunkLevel = chunk.getLevel();
        if (chunkLevel != activeLevel) {
            clear();
            activeLevel = chunkLevel;
        }
        enqueue(chunk.getPos());
    }

    public void enqueue(ChunkPos pos) {
        if (pos == null || pending.size() >= MAX_PENDING) return;
        long key = pos.toLong();
        if (scanned.contains(key) || !queued.add(key)) return;
        pending.addLast(pos);
    }

    public void invalidate(ChunkPos pos) {
        if (pos == null) return;
        long key = pos.toLong();
        scanned.remove(key);
        queued.remove(key);
        pending.removeIf(p -> p.toLong() == key);
        results.remove(key);
    }

    public void clear() {
        pending.clear();
        queued.clear();
        scanned.clear();
        results.clear();
    }

    /** Process at most one chunk per client tick to avoid blocking a frame. */
    public void tick() {
        if (!running) return;

        Minecraft mc = Minecraft.getInstance();
        Level level = mc.level;
        if (level != activeLevel) {
            clear();
            activeLevel = level;
        }
        if (level == null || pending.isEmpty()) return;

        ChunkPos pos = pending.pollFirst();
        if (pos == null) return;
        long key = pos.toLong();
        queued.remove(key);

        LevelChunk chunk = level.getChunkSource().getChunkNow(pos.x, pos.z);
        if (chunk == null) return; // It unloaded before its turn; a future load can enqueue it again.

        try {
            int low = Math.max(Math.min(minY, maxY), level.getMinY());
            int high = Math.min(Math.max(minY, maxY), level.getMaxY() - 1);
            List<ChunkAnomaly> anomalies = ChunkAnalyzer.analyze(chunk, low, high).stream()
                .filter(a -> a.confidence >= confidenceThreshold)
                .toList();

            scanned.add(key);
            if (anomalies.isEmpty()) {
                results.remove(key);
                return;
            }

            results.put(key, anomalies);
            for (Consumer<List<ChunkAnomaly>> listener : listeners) {
                try {
                    listener.accept(anomalies);
                } catch (RuntimeException ignored) {
                    // A faulty consumer must not stop the remaining chunk scans.
                }
            }
        } catch (RuntimeException ex) {
            // Leave it unscanned so a later chunk-load event can retry it.
        }
    }

    public List<ChunkAnomaly> getAnomalies(ChunkPos pos) {
        return results.getOrDefault(pos.toLong(), Collections.emptyList());
    }

    public java.util.Collection<List<ChunkAnomaly>> getAllAnomalies() { return results.values(); }

    public void setMinY(int y) { this.minY = y; }
    public void setMaxY(int y) { this.maxY = y; }
    public void setConfidenceThreshold(double threshold) {
        this.confidenceThreshold = Math.max(0.0, Math.min(1.0, threshold));
    }

    public void addListener(Consumer<List<ChunkAnomaly>> listener) {
        if (listener != null) listeners.addIfAbsent(listener);
    }

    public void removeListener(Consumer<List<ChunkAnomaly>> listener) {
        listeners.remove(listener);
    }
}
