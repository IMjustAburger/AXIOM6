package dev.axiom.core.config;

import java.util.function.Consumer;

/**
 * AXIOM Setting system — every module setting visible in the GUI.
 *
 * Design goals:
 *  • Human-readable names, never internal variable names
 *  • Optional tooltip description shown in the GUI
 *  • Type-safe value access
 *  • onChange callback so modules react immediately
 */
public abstract class Setting<T> {

    private final String name;
    private final String description;
    protected T value;
    protected final T defaultValue;
    private Consumer<T> onChange;

    protected Setting(String name, String description, T defaultValue) {
        this.name        = name;
        this.description = description;
        this.defaultValue = defaultValue;
        this.value        = defaultValue;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public T      getValue()       { return value; }
    public T      getDefault()     { return defaultValue; }

    public void setValue(T v) {
        this.value = v;
        if (onChange != null) onChange.accept(v);
    }

    public void resetToDefault()           { setValue(defaultValue); }
    public void setOnChange(Consumer<T> c) { this.onChange = c; }

    // ── Boolean ───────────────────────────────────────────────────────────────

    public static class BooleanSetting extends Setting<Boolean> {
        public BooleanSetting(String name, String desc, boolean def) { super(name,desc,def); }
        public BooleanSetting(String name, boolean def)              { super(name,"",def); }
        public void toggle() { setValue(!value); }
    }

    // ── Integer ───────────────────────────────────────────────────────────────

    public static class IntSetting extends Setting<Integer> {
        private final int min, max;
        public IntSetting(String name, String desc, int def, int min, int max) {
            super(name,desc,def); this.min=min; this.max=max;
        }
        public IntSetting(String name, int def, int min, int max) { this(name,"",def,min,max); }
        @Override public void setValue(Integer v){ super.setValue(Math.max(min,Math.min(max,v))); }
        public int getMin()      { return min; }
        public int getMax()      { return max; }
        public int getMinValue() { return min; }
        public int getMaxValue() { return max; }
    }

    // ── Double ────────────────────────────────────────────────────────────────

    public static class DoubleSetting extends Setting<Double> {
        private final double min, max;
        public DoubleSetting(String name, String desc, double def, double min, double max) {
            super(name,desc,def); this.min=min; this.max=max;
        }
        public DoubleSetting(String name, double def, double min, double max) { this(name,"",def,min,max); }
        @Override public void setValue(Double v){ super.setValue(Math.max(min,Math.min(max,v))); }
        public double getMin()      { return min; }
        public double getMax()      { return max; }
        public double getMinValue() { return min; }
        public double getMaxValue() { return max; }
    }

    // ── Enum ──────────────────────────────────────────────────────────────────

    public static class EnumSetting<E extends Enum<E>> extends Setting<E> {
        private final Class<E> enumClass;
        public EnumSetting(String name, String desc, E def, Class<E> cls) {
            super(name,desc,def); this.enumClass=cls;
        }
        public EnumSetting(String name, E def, Class<E> cls) { this(name,"",def,cls); }
        public Class<E> getEnumClass() { return enumClass; }
        @SuppressWarnings("unchecked")
        public void cycleNext() {
            E[] vals = enumClass.getEnumConstants();
            setValue(vals[(value.ordinal()+1) % vals.length]);
        }
    }

    // ── Color ─────────────────────────────────────────────────────────────────

    public static class ColorSetting extends Setting<Integer> {
        private boolean rainbow;
        private float   rainbowSpeed = 1.0f;
        private float   hueOffset    = 0.0f;

        public ColorSetting(String name, String desc, int argb) { super(name,desc,argb); }
        public ColorSetting(String name, int argb)              { super(name,"",argb); }

        public boolean isRainbow()           { return rainbow; }
        public void    setRainbow(boolean r) { rainbow=r; }
        public float   getRainbowSpeed()     { return rainbowSpeed; }
        public void    setRainbowSpeed(float s){ rainbowSpeed=s; }

        public int getEffectiveColor() {
            if (!rainbow) return value;
            hueOffset = (hueOffset + rainbowSpeed * 0.005f) % 1.0f;
            return java.awt.Color.HSBtoRGB(hueOffset, 0.8f, 1.0f) | 0xFF000000;
        }
    }

    // ── Sensitivity (human-readable preset enum) ──────────────────────────────
    //
    // Replaces raw threshold values with named levels that map to concrete
    // doubles internally.  The GUI displays "Low / Medium / High / Very High"
    // rather than "0.37".

    public enum Sensitivity {
        LOW      ("Low",       "Flags only very obvious patterns. Fewer false positives."),
        MEDIUM   ("Medium",    "Balanced — good for most situations."),
        HIGH     ("High",      "Catches subtle patterns. Some false positives expected."),
        VERY_HIGH("Very High", "Maximum sensitivity. Use only in confirmed suspicious areas.");

        public final String label;
        public final String tooltip;

        Sensitivity(String label, String tooltip) { this.label=label; this.tooltip=tooltip; }

        /** Convert to the internal confidence threshold used by detectors. */
        public double toConfidenceThreshold() {
            return switch (this) {
                case LOW       -> 0.75;
                case MEDIUM    -> 0.55;
                case HIGH      -> 0.35;
                case VERY_HIGH -> 0.20;
            };
        }

        /** Convert to the internal scan radius multiplier. */
        public int toScanRadius() {
            return switch (this) {
                case LOW       -> 4;
                case MEDIUM    -> 8;
                case HIGH      -> 12;
                case VERY_HIGH -> 16;
            };
        }
    }

    // ── Preset ────────────────────────────────────────────────────────────────

    public enum Preset {
        LOW      ("Low Performance",  "Minimal CPU usage. Smaller range. Best for older hardware."),
        BALANCED ("Balanced",         "Good performance and detection quality for most systems."),
        HIGH     ("High Quality",     "Maximum detection quality. Requires a modern CPU.");

        public final String label;
        public final String tooltip;
        Preset(String l, String t){ label=l; tooltip=t; }
    }
}
